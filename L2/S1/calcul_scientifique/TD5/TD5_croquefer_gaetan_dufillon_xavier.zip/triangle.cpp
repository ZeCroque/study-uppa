#include <iostream>
#include "point.h"
#include "triangle.h"
using namespace std;
	
	void Triangle::_computeArea()
	{
		double temp;
		temp=(((*this)._nodes[1].getX()-(*this)._nodes[0].getX())*((*this)._nodes[2].getY()-(*this)._nodes[0].getY()))-(((*this)._nodes[2].getX()-(*this)._nodes[0].getX())*((*this)._nodes[1].getY()-(*this)._nodes[0].getY()));			

		if (temp<0)
			(*this)._area=-0.5*temp;
		else
			_area=0.5*temp;

	}
	
	void Triangle::_computePerimeter()
	{
		(*this)._perimeter=_nodes[0].distance(_nodes[1])+_nodes[1].distance(_nodes[2])+_nodes[2].distance(_nodes[0]);
	}

		
	void Triangle::initGeometry()
	{
		(*this)._computeArea();
		(*this)._computePerimeter();
	}

	Triangle::Triangle()
	{
		_nodes.reserve(3);
		_nodes.resize(3);
		(*this).initGeometry();
	}

	Triangle::Triangle(const Point& P1, const Point& P2, const Point& P3)
	{
		_nodes.reserve(3);
		_nodes.resize(3);
		_nodes[0]=P1;
		_nodes[1]=P2;
		_nodes[2]=P3;
		(*this).initGeometry();

	}

	Triangle::Triangle(const vector<Point>& vpts)
	{
		_nodes.reserve(3);
		_nodes.resize(3);
		_nodes[0]=vpts[0];
		_nodes[1]=vpts[1];
		_nodes[2]=vpts[2];
		(*this).initGeometry();
	}

	const Point& Triangle::getNode(int i) const
	{
		return _nodes[i];
	}

	Point& Triangle::getNode(int i)
	{
		return _nodes[i];
	}	

	double Triangle::getArea() const
	{
		return _area;
	}

	double Triangle::getPerimeter() const
	{
		return _perimeter;
	}

	ostream & operator << (ostream& os, const Triangle& T)
	{
		os<<T.getNode(0)<<'\n'<<T.getNode(1)<<'\n'<<T.getNode(2)<<'\n';
		return os;
	}

	istream & operator >> (istream& is, Triangle& T)
	{
		is>>T.getNode(0)>>T.getNode(1)>>T.getNode(2);

		if (T.getNode(0).getZ()!=0 || T.getNode(1).getZ()!=0 || T.getNode(2).getZ()!=0)
		{
			T.getNode(0).getZ()=0;
			T.getNode(1).getZ()=0;
			T.getNode(2).getZ()=0;
			cout<<"La composante Z était non nulle pour au moins un des sommets, elle a été réiniatilisée à 0."<<endl;
		}

	
		T.initGeometry();
	}
