#include <iostream>
#include "point.h"
#include "triangle.h"
using namespace std;

int main()
{

	/*---------------------
			DEMO POINT
	---------------------*/
	Point P1;
	Point P2;

	cout<<"------DEMO CLASSE POINT------"<<endl;
	cout<<"Entrez successivement les coordonnées x, y & z du premier point, en validant chaque valeur avec ENTREE"<<endl;
	cin>>P1;
	cout<<"Entrez successivement les coordonnées x, y & z du deuxième point, en validant chaque valeur avec ENTREE"<<endl;
	cin>>P2;
	cout<<"Point 1 :\n"<<P1<<endl;
	cout<<"Point 2 :\n"<<P2<<endl;
	cout<<"Distance entre les points : "<<P1.distance(P2)<<endl;

	/*---------------------
		DEMO TRIANGLE
	---------------------*/

	Triangle T;

	cout<<"\n\n------DEMO CLASSE TRIANGLE------"<<endl;
	cout<<"Entrez successivement les coordonnées des trois sommets du triangle, en validant chaque valeur avec ENTREE"<<endl;
	cin>>T;
	cout<<"Triangle :\n"<<T<<endl;
	cout<<"Aire : "<<T.getArea()<<endl;
	cout<<"Périmètre : "<<T.getPerimeter()<<endl;

	return 0;
}
