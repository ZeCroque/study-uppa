#ifndef __menu_h
#define __menu_h

#include "alerte.h"
#include "unite.h"
#include "outils.h"

//Affiche le menu permettant de déclencher une alerte
void declencherAlerte(alerte* altTab);

//Affiche le menu permettant le traitement des alertes
void traitementAlertes(alerte* altTab, unite* uniTab);

//Affiche le menu permettant la gestion des unités
void gestionOperation(unite* uni);

//Affiche les unités déployées sur une alerte
void afficherTraitementAlerte(alerte* alt);


#endif
