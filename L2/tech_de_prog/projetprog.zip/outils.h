#ifndef __outils_h
#define __outils_h

#include <stdio.h>
#include <stdlib.h>

int lireChaineCaractere(char** str);

#endif
