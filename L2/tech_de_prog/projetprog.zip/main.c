#include "menu.h"


int main (int argc, char *argv[])
{
	/*alerte** altTab=NULL;
	altTab=malloc(sizeof(alerte*));
	*altTab=malloc(sizeof(alerte));

	int* iAltSize=NULL;
	iAltSize=malloc(sizeof(int));
	*iAltSize=0;

	ajouterAlerte(altTab, iAltSize);
	ajouterAlerte(altTab, iAltSize);
	affichageTableauAlertes((*altTab),*iAltSize);

	free(*altTab);
	free(altTab);*/

	unite** uniTab=NULL;
	uniTab=malloc(sizeof(unite*));
	*uniTab=malloc(sizeof(unite));

	int* iUniSize=NULL;
	iUniSize=malloc(sizeof(int));
	*iUniSize=0;

	ajouterUnite(uniTab, iUniSize);
	ajouterUnite(uniTab, iUniSize);
	affichageTableauUnites((*uniTab),*iUniSize);

	free(*uniTab);
	free(uniTab);


	return 0;
}
