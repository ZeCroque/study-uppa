#include "unite.h"
#include "alerte.h"
#include "time.h"

void ajouterUnite(unite** uniTab, int* iSize)
{
	unite uniTmp;
	time_t temps=NULL;
	temps=time(NULL);

	*uniTab=realloc(*uniTab, ((*iSize)+1)*sizeof(unite));

	uniTmp.dCode=(double)temps;

	system("clear");
	printf("*****NOUVELLE UNITE*****\n\nNom de l'Unite : ");
	lireChaineCaractere(&(uniTmp.strNom));
	system("clear");
	printf("*****NOUVELLE UNITE*****\n\nBase de l'unite : ");
	lireChaineCaractere(&(uniTmp.strBase));
	do
	{
		system("clear");
		printf("*****NOUVELLE UNITE*****\n\n-4 : Routier\n-5 : Aérien\n-6 : Nautique\nMoyen de transport de l'unité : ");
		scanf("%d%*c", &(uniTmp.iTransport));
	} while (uniTmp.iTransport!=ROUTE && uniTmp.iTransport!=AIR && uniTmp.iTransport!= MER);
	do
	{
		system("clear");
		printf("*****NOUVELLE UNITE*****\n\n-7 : Active\n-8 : Repos\n-9 : Réaprovisionnement\nDisponibilite de l'unité : ");
		scanf("%d%*c", &(uniTmp.iDisponibilite));
	} while (uniTmp.iDisponibilite!=ACTIVE && uniTmp.iDisponibilite!=EN_REPOS && uniTmp.iDisponibilite!= EN_REAPPROVISIONNEMENT);
	do
	{
		system("clear");
		printf("*****NOUVELLE UNITE*****\n\n-10 : En Alerte\n-11 : En Route\n-12 : Sur Operation\nStatut de l'unité : ");
		scanf("%d%*c", &(uniTmp.iStatut));
	} while (uniTmp.iStatut!=EN_ALERTE && uniTmp.iStatut!=EN_ROUTE && uniTmp.iStatut!= SUR_OPERATION);

	*iSize+=1;
	(*uniTab)[(*iSize)-1]=uniTmp;

}

void modifierUnite(unite* uni)
{
	int i;
	system("clear");
	printf("********************************************\n")
	printf("* modifier les parametres de votre unité  **\n")
	printf("********************************************\n")
	printf("**  1/ Nom de l'unité                     **\n")
	printf("**  2/ Base de l'unité                    **\n")
	printf("**  3/ Moyen de transport de l'unité      **\n")
	printf("**  4/ Disponibilite de l'unité           **\n")
	printf("**  5/ Statut de l'unité                  **\n")
	printf("********************************************\n")
	printf("********************************************\n")
	scanf("%d",&i)

	switch (i) {
		case 1:
			system("clear");
			printf("*****MODIFIER UNITE*****\n\nNom de l'Unite : ");
			lireChaineCaractere(&(uniTmp.strNom));
			break;

		case 2:do
	{
		system("clear");
		printf("*****MODIFIER UNITE*****\n\n-4 : Routier\n-5 : Aérien\n-6 : Nautique\nMoyen de transport de l'unité : ");
		scanf("%d%*c", &(uniTmp.iTransport));
	} while (uniTmp.iTransport!=ROUTE && uniTmp.iTransport!=AIR && uniTmp.iTransport!= MER);
			system("clear");
			printf("*****MODIFIER UNITE*****\n\nBase de l'unite : ");
			lireChaineCaractere(&(uniTmp.strBase));
			break;

		case 3:
			do
			{
				system("clear");
				printf("*****MODIFIER UNITE*****\n\n-4 : Routier\n-5 : Aérien\n-6 : Nautique\nMoyen de transport de l'unité : ");
				scanf("%d%*c", &(uniTmp.iTransport));
			} while (uniTmp.iTransport!=ROUTE && uniTmp.iTransport!=AIR && uniTmp.iTransport!= MER);
			break;

		case 4:
			do
			{
				system("clear");
				printf("*****MODIFIER UNITE*****\n\n-7 : Active\n-8 : Repos\n-9 : Réaprovisionnement\nDisponibilite de l'unité : ");
				scanf("%d%*c", &(uniTmp.iDisponibilite));
			} while (uniTmp.iDisponibilite!=ACTIVE && uniTmp.iDisponibilite!=EN_REPOS && uniTmp.iDisponibilite!= EN_REAPPROVISIONNEMENT);
			break;

		case 5:
			do
			{
				system("clear");
				printf("*****MODIFIER UNITE*****\n\n-10 : En Alerte\n-11 : En Route\n-12 : Sur Operation\nStatut de l'unité : ");
				scanf("%d%*c", &(uniTmp.iStatut));
			} while (uniTmp.iStatut!=EN_ALERTE && uniTmp.iStatut!=EN_ROUTE && uniTmp.iStatut!= SUR_OPERATION);
			break;
	}
}

void affichageUnite(unite uni)
{
	printf("*****AFFICHAGE DE L'UNITE*****\n\nCode unique : %.2f\nNom : %s\nType d'unite : ", uni.dCode, uni.strNom);
	switch(uni.iTransport)
	{
		case ROUTE :
			printf("Routier\nDisponibilité de l'unité : ");
			break;
		case MER :
			printf("Nautique\nDisponibilité de l'unité : ");
			break;
		case AIR :
			printf("Aérien\nDisponibilité de l'unité : ");
			break;
		default:
			printf("ERREUR: TYPE INCONNU\n");
			exit(-1);
			break;
	}
	switch(uni.iDisponibilite)
	{
		case ACTIVE :
			printf("Active\nStatut : ");
			break;
		case EN_REPOS :
			printf("En repos\nStatut : ");
			break;
		case EN_REAPPROVISIONNEMENT :
			printf("En réapprovisionnement\nStatut : ");
			break;
		default:
			printf("ERREUR: DISPONIBILITE INCONNUE\n");
			exit(-1);
			break;
	}
	switch(uni.iStatut)
	{
		case EN_ALERTE :
			printf("En alerte\n");
			break;
		case EN_ROUTE :
			printf("En route\n");
			break;
		case SUR_OPERATION :
			printf("Sur opération\n");
			break;
		default:
			printf("ERREUR: STATUT INCONNU\n");
			exit(-1);
			break;
	}
	printf("Base : %s\n", uni.strBase);


}

void affichageTableauUnites(unite* uniTab, int iSize)
{
	int i;
	system("clear");
	for(i=0; i<iSize; i++)
	{
		affichageUnite(uniTab[i]);
	}
}

void supprimerUnite(unite* uniTab, int iCode)
{

}

void supprimerTableauUnite(unite* uniTab)
{

}
