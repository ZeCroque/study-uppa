#include "menu.h"

void declencherAlerte(alerte* altTab)
{

}

void traitementAlertes(alerte* altTab, unite* uniTab)
{

}

void gestionOperation(unite* uni)
{

}

void afficherTraitementAlerte(alerte* alt)
{

}
