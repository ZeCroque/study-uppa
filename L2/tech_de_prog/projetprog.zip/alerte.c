#include "alerte.h"
#include "unite.h"
#include "time.h"

void ajouterAlerte(alerte** altTab, int* iSize)
{
	alerte altTmp;
	time_t temps=NULL;
	temps=time(NULL);

	*altTab=realloc(*altTab, ((*iSize)+1)*sizeof(alerte));

	altTmp.dCode=(double)temps;

	do
	{
		system("clear");
		printf("*****NOUVELLE ALERTE*****\n\n0 : Incendie\n1 : Accident de la route\n2 : Accident en mer\n3 : Accident en montagne\n4 : Malaise\n5 : Explosion\n6 : Accident de la vie\nType d'alerte : ");
		scanf("%d%*c", &(altTmp.iType));
	} while (altTmp.iType!=INCENDIE && altTmp.iType!=ACCIDENT_ROUTE && altTmp.iType!= ACCIDENT_MER && altTmp.iType!= ACCIDENT_MONTAGNE && altTmp.iType!=MALAISE && altTmp.iType!=EXPLOSION && altTmp.iType!=ACCIDENT_DE_LA_VIE);
	do
	{
		system("clear");
		printf("*****NOUVELLE ALERTE*****\n\n-1 : Nominal\n-2 : Urgence\n-3 : URGENCE ABSOLUE\nGravité de l'alerte : ");
		scanf("%d%*c", &(altTmp.iNiveau));
	} while (altTmp.iNiveau!=NOMINAL && altTmp.iNiveau!=URGENCE && altTmp.iNiveau!=URGENCE_ABSOLUE);
	system("clear");
	printf("*****NOUVELLE ALERTE*****\n\nLieu de l'alerte : ");
	lireChaineCaractere(&(altTmp.strLieu));
	do
	{
		system("clear");
		printf("*****NOUVELLE ALERTE*****\n\nNombre de victimes (doit être d'au moins zéro) : ");
		scanf("%d%*c", &(altTmp.iVictimes));
	} while (altTmp.iVictimes<0);
	system("clear");
	printf("*****NOUVELLE ALERTE*****\n\nDescription de l'alerte : ");
	lireChaineCaractere(&(altTmp.strDescription));


	*iSize+=1;
	(*altTab)[(*iSize)-1]=altTmp;
}

void modifierAlerte(alerte* alt)
{
	int i;
	system("clear");
	printf("********************************************\n")
	printf("* modifier les parametres de votre alerte **\n")
	printf("********************************************\n")
	printf("**  1/ type d'alerte                      **\n")
	printf("**  2/ gravité de l'alerte                **\n")
	printf("**  3/ lieu de l'alerte                   **\n")
	printf("**  4/ Nombre de victimes                 **\n")
	printf("**  5/ Description de l'alerte            **\n")
	printf("********************************************\n")
	printf("********************************************\n")
	scanf("%d",&i)
	switch (i) {
		case 1:
			do
			{
				system("clear");
				printf("*****MODIFIER ALERTE*****\n\n0 : Incendie\n1 : Accident de la route\n2 : Accident en mer\n3 : Accident en montagne\n4 : Malaise\n5 : Explosion\n6 : Accident de la vie\nType d'alerte : ");
				scanf("%d%*c", &(altTmp.iType));
			} while (altTmp.iType!=INCENDIE && altTmp.iType!=ACCIDENT_ROUTE && altTmp.iType!= ACCIDENT_MER && altTmp.iType!= ACCIDENT_MONTAGNE && altTmp.iType!=MALAISE && altTmp.iType!=EXPLOSION && altTmp.iType!=ACCIDENT_DE_LA_VIE);
			break;
		case 2:
			do
			{
				system("clear");
				printf("*****MODIFIER ALERTE*****\n\n-1 : Nominal\n-2 : Urgence\n-3 : URGENCE ABSOLUE\nGravité de l'alerte : ");
				scanf("%d%*c", &(altTmp.iNiveau));
			} while (altTmp.iNiveau!=NOMINAL && altTmp.iNiveau!=URGENCE && altTmp.iNiveau!=URGENCE_ABSOLUE);
			break;
		case 3:
			system("clear");
			printf("*****MODIFIER ALERTE*****\n\nLieu de l'alerte : ");
			lireChaineCaractere(&(altTmp.strLieu));
			break;
		case 4:
			do
			{
				system("clear");
				printf("*****MODIFIER ALERTE*****\n\nNombre de victimes (doit être d'au moins zéro) : ");
				scanf("%d%*c", &(altTmp.iVictimes));
			} while (altTmp.iVictimes<0);
			break;
		case 5:
			system("clear");
			printf("*****MODIFIER ALERTE*****\n\nDescription de l'alerte : ");
			lireChaineCaractere(&(altTmp.strDescription));
			break;
	}
}

void affichageAlerte(alerte alt)
{
	printf("*****AFFICHAGE DE L'ALERTE*****\n\nCode unique : %.2f\nType d'alerte : ", alt.dCode);
	switch(alt.iType)
	{
		case INCENDIE :
			printf("Incendie\nGravité de l'alerte : ");
			break;
		case ACCIDENT_ROUTE :
			printf("Accident de la route\nGravité de l'alerte : ");
			break;
		case ACCIDENT_MER :
			printf("Accident en mer\nGravité de l'alerte : ");
			break;
		case ACCIDENT_MONTAGNE :
			printf("Accident en montagne\nGravité de l'alerte : ");
			break;
		case MALAISE :
			printf("Malaise\nGravité de l'alerte : ");
			break;
		case EXPLOSION :
			printf("Explosion\nGravité de l'alerte : ");
			break;
		case ACCIDENT_DE_LA_VIE :
			printf("Accident de la vie\nGravité de l'alerte : ");
			break;
		default:
			printf("ERREUR: TYPE INCONNU\n");
			exit(-1);
			break;
	}
	switch(alt.iNiveau)
	{
		case NOMINAL :
			printf("Nominal\nLieu : ");
			break;
		case URGENCE :
			printf("Urgence\nLieu : ");
			break;
		case URGENCE_ABSOLUE :
			printf("URGENCE ABSOLUE\nLieu : ");
			break;
		default:
			printf("ERREUR: NIVEAU INCONNU\n");
			exit(-1);
			break;
	}
	printf("%s\nNombre de victimes : %d\nDescription : %s\n", alt.strLieu, alt.iVictimes, alt.strDescription);


}

void affichageTableauAlertes(alerte* altTab, int iSize)
{
	int i;
	system("clear");
	for(i=0; i<iSize; i++)
	{
		affichageAlerte(altTab[i]);
	}
}

void supprimerAlerte(alerte* altTab, int iCode)
{

}

void supprimerTableauAlerte(alerte* altTab)
{

}
