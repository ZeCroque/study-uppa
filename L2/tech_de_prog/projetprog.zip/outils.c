#include "outils.h"

int lireChaineCaractere(char** str)
{
	char tmp;
	int i=1;
		
	*str=malloc(sizeof(char));
	do
	{
		tmp=getchar();
		*str=realloc(*str, i*sizeof(char));
		if(*str==NULL)
		{
			printf("Erreur allocation\n");
			exit(-1);
		}

		if (tmp=='\n' || tmp==EOF)
		{
			(*str)[i-1]='\0';
		}
		else
		{
			(*str)[i-1]=tmp;
		}
		i++;

	} while(tmp!='\n' && tmp!='\0' && tmp!=EOF);
 
	return i-2;	
}
