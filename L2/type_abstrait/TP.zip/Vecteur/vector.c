#include "vector.h"

Vector vide()
{
	Vector v=malloc(sizeof(Cellule));
	(*v).elem=0;
	(*v).suivant=NULL;


	
	return v;
}


Elt premier(Vector v)
{
	return (*v).elem;
}

int taille(Vector v)
{
	int i=0;
	Vector aux=v;

	while ((*aux).suivant!=NULL)
	{
		aux=(*aux).suivant;
		i++;
	}
	return i;
}


void inserer(Vector v, int pos, Elt element)
{
	int i;
	Vector temp=malloc(sizeof(Cellule));
	Vector aux=v;

	(*temp).elem=element;

	if (pos!=1)
	{
		for (i=1; i<pos;i++)
		{
			aux=(*aux).suivant;
		}
		(*temp).suivant=(*aux).suivant;
		(*aux).suivant=temp;
	}
	else
	{
		(*temp).suivant=aux;
		v=temp;
	}
	
}
/*
Vector modifier(Vector v, int pos, Elt element)
{
	
}
*/
Vector supprimer(Vector v, int pos)
{
	Vector temp=malloc(sizeof(Cellule));
	Vector aux=v;
	int i=1;
	if (pos!=1)
	{
		for (i=1 ; i<pos; i++)
		{
			aux=(*aux).suivant;
		}
		temp=(*aux).suivant;
		aux=(*aux).suivant;
	}
	else
	{
		temp=v;
		v=(*v).suivant;
	}
	free(temp);
}

Elt ieme(Vector v, int pos)
{
	int i;
	Vector aux;
	for (i=1;i<pos;i++)
	{
		aux=(*aux).suivant;
	}
	return (*aux).elem;
}
