#include <stdio.h>
#include "vector.h"

int main()
{
	Vector v=vide();
	
	inserer(v, 1, 8);
	inserer(v, 2, 84);
	//supprimer(v, 1);
	printf("%d\n", ieme(v, 2));
}
