#include "Polynom.h"

using namespace L2Info;

Polynom::Polynom()
{
	_deg=0;
	_coeff=NULL;
}

Polynom::Polynom(int deg)
{
	_deg=deg;
	_coeff=NULL;
}

Polynom::Polynom(int deg, double* coeff)
{
	_deg=deg;
	_coeff=new double[deg+1];
	_coeff=coeff;
}

Polynom::~Polynom()
{
	delete[] _coeff;
}

int Polynom::getDegree() const
{
	return _deg;
}

void Polynom::setCoeffAndDegree(int deg, double* coeff)
{
	_deg=deg;
	if(_coeff!=NULL)
	{
		delete[] _coeff;
	}
	_coeff=new double[deg+1];
	_coeff=coeff;

}

double & Polynom::operator [] (int i)
{
	return _coeff[i];
}

double Polynom::operator [] (int i) const
{
	return _coeff[i];
}

Polynom& Polynom::operator=(const Polynom& p)
{
	_deg=p._deg;
	if(_coeff!=NULL)
	{
		delete[] _coeff;
	}
	_coeff=new double[p._deg+1];
	_coeff=p._coeff;
}

void Polynom::operator +=(const Polynom& p)
{
	int i;
	double* tmp;

	if (_deg<p._deg)
	{
		tmp=new double[p._deg+1];
		for(i=_deg+1; i<=p._deg; i++)
		{
			tmp[i]=p._coeff[i];
		}
		for (i=0; i<=_deg; i++)
		{
			tmp[i]=p._coeff[i]+_coeff[i];
		}
		_deg=p._deg;
		if(_coeff!=NULL)
		{
			delete[] _coeff;
		}
		_coeff=new double[p._deg+1];
		_coeff=tmp;
	}
	else
	{
		tmp=new double[_deg+1];
		for(i=p._deg+1; i<=_deg; i++)
		{
			tmp[i]=_coeff[i];
		}
		for (i=0; i<=p._deg; i++)
		{
			tmp[i]=p._coeff[i]+_coeff[i];
		}
		if(_coeff!=NULL)
		{
			delete[] _coeff;
		}
		_coeff=new double[_deg+1];
		_coeff=tmp;
	}
	
}

void Polynom::operator *=(const Polynom& p)
{

}

void Polynom::operator *=(double a)
{
	int i;

	for (i=0; i<=_deg; i++)
	{
		_coeff[i]*=a;
	}
}

double Polynom::operator()(double x)
{
	int i;
	double tmp=0;

	for(i=0; i<=_deg; i++)
	{
		tmp+=pow(_coeff[i], i);
	}
}

ostream& operator << (ostream& os, const L2Info::Polynom& p)
{
	int i;
	int size=p.getDegree()+1;

	for (i=0; i<size; i++)
	{
		if (i==0)
		{
			os<<p[i];
		}
		else if (i==1)
		{
			os<<" + "<<p[i]<<"x";
		}
		else
		{
			os<<" + "<<p[i]<<"x^"<<i;
		}
	}
	os<<endl;
}
