#include "Polynom.h"

using namespace L2Info;

int main()
{
	double* coeff1=new double[2];
	coeff1[0]=1;
	coeff1[1]=1;
	Polynom p1(1, coeff1);
	cout<<p1;

	/*double* coeff2=new double[3];
	coeff2[0]=2;
	coeff2[1]=2;
	coeff2[2]=2;
	Polynom p2(2, coeff2);
	cout<<p2;*/
	
	p1*=3;
	cout<<p1(1);

	
	return 0;
}
