#ifndef __vecteur_h
#define __vecteur_h

#include <iostream>
#include <stdio>

using namespace std;

class VecteurChar
{
	private :
		int _nelem;
		char *_v;
		string_key;
		bool_encoded;
	public :
		VecteurChar();
		VecteurChar(int n);
		VecteurChar(const string& s);
		~VecteurChar();
		void reDim(int n);
		int getSize() const;
		void setKey(const string &s);
		void encode();
		void decode();
		char & operator [] (int i);
		char operatore [] (int i) const;
		VecteurChar& operator = (const VecteurChar& V);
		VecteurChar& operator = (const string& s);
};

ostream& operator << (ostream os, const VecteurChar& v);

#endif