
vecteur::VecteurChar(){}
vecteur::VecteurChar(int n){}
vecteur::VecteurChar(const string& s){}
vecteur::~VecteurChar(){}
void vecteur::reDim(int n){}
int vecteur::getSize() const{}
void vecteur::setKey(const string &s){}
void vecteur::encode(){}
void vecteur::decode(){}
char & vecteur::operator [] (int i){}
char vecteur::operator [] (int i) const{}
VecteurChar& vecteur::operator = (const VecteurChar& V){}
VecteurChar& vecteur::operator = (const string& s){}
ostream& operator << (ostream os, const VecteurChar& v){}