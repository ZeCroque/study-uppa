
let panier = {
  total: 12.5,
  articles: [
    {
      article: 'Oranges',
      quantité: 3,
      prixUnitaire: 1.5,
      prix: 4.5
    }, {
      article: 'Fraises',
      quantité: 1,
      prixUnitaire: 8,
      prix: 8
    }
  ]
};

  window.addEventListener("load", function()
  {
    let oriCheckboxTab=document.getElementsByClassName('origines')[0];
    for(let i=1; i<oriCheckboxTab.childElementCount; i++)
    {
        let oriCheckboxElt=oriCheckboxTab.children[i].children[0];
        oriCheckboxElt.addEventListener("change", oriCheckboxListener)
    }
    fabriqueInterfaceGraphique(articles, tarifs);
  });

function oriCheckboxListener()
{
  let checkboxElt=event.target;
  let category=checkboxElt.parentNode.parentNode;
  let articleTab=document.getElementsByClassName('articles')[0];
  let i;

  if(checkboxElt.checked==true)
  {
    if(checkboxElt.name=='ori_toutes')
    {
      for(i=2; i<category.childElementCount;i++)
      {
        category.children[i].children[0].checked=false;
      }
    }
    else if(checkboxElt.name!='ori_toutes')
    {
      category.children[1].children[0].checked=false;
    }
    for(i=0; i<articles.length; i++)
    {
      if(articleTab.children[i].children[1].children[1].children[0].innerHTML==checkboxElt.nextElementSibling.innerHTML || checkboxElt.name=='ori_toutes')
      {
          articleTab.children[i].style.display = "inline-block";
      }
    }
  }
  else
  {
    for(i=0; i<articles.length; i++)
    {
        if(articleTab.children[i].children[1].children[1].children[0].innerHTML==checkboxElt.nextElementSibling.innerHTML || checkboxElt.name=='ori_toutes')
        {
          articleTab.children[i].style.display = "none";
        }
    }
  }
}

function fabriqueInterfaceGraphique(articles, tarifs)
{
	let dirImages = "./images/";

	let articleList = document.getElementsByClassName('articles')[0];
	let articleElt = document.getElementsByClassName('article')[0];
	let size = articles.length;
	let newArticle=articleElt;
  let i=0;
  let j=0;

	for (i=0; i<size; i++)
	{
		if (i!=0)
		{
			newArticle = articleElt.cloneNode(true);
			articleList.appendChild(newArticle);
		}

    let articlePhoto = articles[i].photos[0];
    let articleImgStyle = newArticle.getElementsByClassName('img')[0].style;
    articleImgStyle.backgroundImage = "url('" + dirImages + articlePhoto.url + "')";
    articleImgStyle.backgroundPositionX = -articlePhoto.x + "px";
    articleImgStyle.backgroundPositionY= -articlePhoto.y + "px";
    articleImgStyle.width = articlePhoto.w + "px";
    articleImgStyle.height = articlePhoto.h + "px";

    let articleName = newArticle.getElementsByClassName('nom')[0];
    articleName.innerHTML=articles[i].nom;

    let refArticle=articles[i].ref;
    let priceLabel = newArticle.getElementsByClassName('prix')[0];
    let origineLabel = newArticle.getElementsByClassName('origine')[0];
    let uniteLabel = newArticle.getElementsByClassName('unité')[0];
    for (j=0; j<tarifs.length && tarifs[j].ref!=refArticle; j++);
    if (j!=tarifs.length+1)
    {
      priceLabel.children[0].innerHTML=tarifs[j].prix;
      priceLabel.children[1].innerHTML=tarifs[j].unité;
      origineLabel.children[0].innerHTML=tarifs[j].origine;
      uniteLabel.innerHTML=tarifs[j].unité;
    }
	}
}

function envoyerCommande() {
  let email = "destinataire@mail.com";
  let sujet = "commande de fruits et légumes";
  let corps = "\nCommande\n\nVoici un récapitulatif des articles commandés\npour un montant de 12.50 € :\n...\n..."
  email = encodeURIComponent(email);
  sujet = encodeURIComponent(sujet);
  corps = encodeURIComponent(corps);
  let uri = "mailto:" + email + "?subject=" + sujet + "&body=" + corps;
  window.location.href = uri;
}
