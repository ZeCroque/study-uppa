
var tarifs = [
  {
    'ref':'pr',
    'origine':'France',
    'prix':2,
    'unité':'Kg'
  },
  {
    'ref':'pj',
    'origine':'France',
    'prix':2,
    'unité':'Kg'
  },
  {
    'ref':'po',
    'origine':'France',
    'prix':2,
    'unité':'Kg'
  },
  {
    'ref':'or',
    'origine':'Maroc',
    'prix':1.5,
    'unité':'Kg'
  },
  {
    'ref':'av',
    'origine':'Pérou',
    'prix':1.5,
    'unité':'Pièce'
  },
  {
    'ref':'fr',
    'origine':'France',
    'prix':3,
    'unité':'Barquette 250g'
  },
  {
    'ref':'fr',
    'origine':'France',
    'prix':5,
    'unité':'Barquette 500g'
  },
  {
    'ref':'fr',
    'origine':'Espagne',
    'prix':8,
    'unité':'Plateau 1kg'
  },
  {
    'ref':'pa',
    'origine':'Maroc',
    'prix':3,
    'unité':'Kg'
  },
]
